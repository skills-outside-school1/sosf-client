export const dataRoutes = [
    {
        id: 1,
        path: "/data1",
        text: "data1"
    },
    {
        id: 2,
        path: "/data1",
        text: "data1"
    },
    {
        id: 3,
        path: "/data1",
        text: "data1"
    },
    {
        id: 4,
        path: "/data1",
        text: "data1"
    },
    {
        id: 5,
        path: "/data1",
        text: "data1"
    },
]